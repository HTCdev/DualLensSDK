DimensionPlusDemo Notes:

- See the dependencies for the APIs used in this example under the libs folder
    if accessing the DimensionPlusUtility class, you will also need to add to the libs folder:
    armeabi/libDimensionPlusLib.so from the DependencyLibs folder
    
- this sample does not require an HTC One M8 device to run unless using libDimensionPlusLib or DualLens dependencies
