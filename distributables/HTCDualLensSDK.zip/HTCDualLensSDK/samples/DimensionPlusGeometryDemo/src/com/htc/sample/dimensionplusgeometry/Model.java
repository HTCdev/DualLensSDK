package com.htc.sample.dimensionplusgeometry;

public class Model extends Mesh {
	public Model() {
		this(1, 1);
	}
	public Model(float width, float height) {
//		setIndices(indices);
//		setVertices(vertices);
//		setTextureCoordinates(textureCoordinates);
	}
}
