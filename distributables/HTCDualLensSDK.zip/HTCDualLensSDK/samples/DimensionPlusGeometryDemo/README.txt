DualLensFullDemo Notes:

- copy the dependency lib files into the libs folder 

- this sample requires a HTC One M8 device to run
