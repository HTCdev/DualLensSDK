DualLensDemo Notes:

- Copy dependencies for the APIs used in this example to the libs folder
    if accessing the DimensionPlusUtility class, you will also need to add to the libs folder:
    armeabi/libDimensionPlusLib.so
    if accessing DimensionPlusView, you will also need 
    libMatrix and armeabi-v7a/libHMSGallery_libMatrix.jar
    
- This sample requires an HTC One (M8) to run

- Note: There is a known issue on Android 5, a fix is forthcoming
