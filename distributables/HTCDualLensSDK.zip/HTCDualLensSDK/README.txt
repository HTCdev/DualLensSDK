Sample projects are included in the samples folder.

Please read the README.txt for each sample project. The dependency libraries depend on the API used, please refer to the samples.

Additional sample projects and documentation are available online at:

http://htcdev.com/devcenter/opensense-sdk/htc-dual-lens-api

